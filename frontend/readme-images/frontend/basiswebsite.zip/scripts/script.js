// JavaScript Document
console.log("hi");